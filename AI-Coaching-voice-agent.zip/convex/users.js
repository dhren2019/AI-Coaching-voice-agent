import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

export const CreateUser = mutation({
    args: {
        name: v.string(),
        email: v.string()
    },
    handler: async (ctx, args) => {
        // if user already exist
        const userData = await ctx.db.query('users')
            .filter(q => q.eq(q.field('email'), args.email))
            .collect();
        //If not Then add new user
        if (userData?.length == 0) {
            const data = {
                name: args.name,
                email: args.email,
                credits: 5000,
                subscriptionId: null
            }
            const result = await ctx.db.insert('users', {
                ...data
            });

            return data;
        }
        return userData[0]
    }
})

export const UpdateUserToken = mutation({
    args: {
        id: v.id('users'),
        credits: v.number()
    },
    handler: async (ctx, args) => {
        await ctx.db.patch(args.id, {
            credits: args.credits
        })
    }
})

// Consulta para obtener usuario por email
export const getUserByEmail = query({
    args: { email: v.string() },
    handler: async (ctx, args) => {
        const users = await ctx.db
            .query('users')
            .filter(q => q.eq(q.field('email'), args.email))
            .collect();
        return users;
    }
});

export const updateUserSubscription = mutation({
    args: {
        subscriptionId: v.string(),
        stripeCustomerId: v.string()
    },
    handler: async (ctx, args) => {
        const { subscriptionId, stripeCustomerId } = args;
        
        console.log('🔄 Iniciando actualización de suscripción:', {
            subscriptionId,
            stripeCustomerId,
            timestamp: new Date().toISOString()
        });
        
        try {
            // Buscar usuario por stripeCustomerId
            console.log('🔍 Buscando usuario por stripeCustomerId:', stripeCustomerId);
            
            const users = await ctx.db
                .query('users')
                .filter(q => q.eq(q.field('stripeCustomerId'), stripeCustomerId))
                .collect();

            console.log('📊 Resultados de búsqueda:', {
                usersEncontrados: users.length,
                detalles: users.map(u => ({
                    id: u._id,
                    email: u.email,
                    creditsActuales: u.credits,
                    subscriptionIdActual: u.subscriptionId || 'unset'
                }))
            });

            if (users.length === 0) {
                // Si no encontramos por stripeCustomerId, intentamos por email
                console.log('🔄 Intentando búsqueda alternativa por email del usuario');
                
                // Aquí deberíamos tener el email del usuario desde Stripe
                // Por ahora continuamos con el error
                console.error('❌ Usuario no encontrado en Convex:', {
                    stripeCustomerId,
                    subscriptionId,
                    timestamp: new Date().toISOString()
                });
                throw new Error('No se encontró el usuario');
            }

            const user = users[0];
            console.log('👤 Usuario encontrado en Convex:', {
                userId: user._id,
                email: user.email,
                creditsActuales: user.credits,
                subscriptionIdAnterior: user.subscriptionId || 'unset',
                nuevoSubscriptionId: subscriptionId
            });
            
            // Actualizar el usuario con la información de la suscripción
            console.log('📝 Iniciando actualización de usuario:', {
                userId: user._id,
                subscriptionIdAnterior: user.subscriptionId || 'unset',
                nuevoSubscriptionId: subscriptionId,
                nuevosCredits: 50000
            });

            // Actualizar usuario con el nuevo subscriptionId
            await ctx.db.patch(user._id, {
                subscriptionId: subscriptionId, // Guardamos el nuevo subscriptionId
                stripeCustomerId: stripeCustomerId,
                credits: 50000 // Establecer créditos del plan Pro
            });

            // Obtener y retornar el usuario actualizado
            const updatedUser = await ctx.db.get(user._id);
            console.log('✅ Usuario actualizado exitosamente:', {
                userId: updatedUser._id,
                email: updatedUser.email,
                subscriptionIdAnterior: user.subscriptionId || 'unset',
                subscriptionIdNuevo: updatedUser.subscriptionId,
                credits: updatedUser.credits,
                timestamp: new Date().toISOString()
            });
            
            return updatedUser;
        } catch (error) {
            console.error('❌ Error en updateUserSubscription:', {
                error: error.message,
                stack: error.stack,
                stripeCustomerId,
                subscriptionId,
                timestamp: new Date().toISOString()
            });
            throw error;
        }
    },
});

// Eliminar suscripción
export const removeSubscription = mutation({
    args: {
        email: v.string(),
    },
    handler: async (ctx, args) => {
        const users = await ctx.db
            .query('users')
            .filter(q => q.eq(q.field('email'), args.email))
            .collect();

        if (users.length === 0) {
            throw new Error("❌ No se encontró usuario con ese email");
        }

        const user = users[0];

        // Eliminar subscriptionId y resetear créditos al plan gratuito
        await ctx.db.patch(user._id, {
            subscriptionId: null,
            credits: 5000 // Resetear a créditos del plan gratuito
        });

        console.log("✅ Suscripción eliminada para el usuario:", args.email);
        return user;
    },
});
  